const chalk = require("chalk")
const fs = require("fs")

//owmner v card
//domain && apikey && capikey && egg sesuai panel klian ya
// subrek channel DzakkyOfficial
global.owner = ['6285727562218'] //ur owner number
global.ownernomer = "6285727562218" //ur owner number2
global.ownername = "𝐃𝐙𝐀𝐊𝐊𝐘 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋" //ur owner name
global.ytname = "𝐃𝐙𝐀𝐊𝐊𝐘 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋" //ur yt chanel name
global.socialm = "𝐃𝐙𝐀𝐊𝐊𝐘 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋" //ur github or insta name
global.location = "Arab Saudi" //ur location
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = '_' // isi dengan domain panel lu
global.apikey = '_' // Isi Apikey Plta Lu
global.capikey = '_' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

//new
global.ownergc = "𝐃𝐙𝐀𝐊𝐊𝐘 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋"
global.botname = "𝐃𝐙𝐀𝐊𝐊𝐘 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋"
global.ownerNumber = ["6285727562218@s.whatsapp.net"]
global.ownerweb = "_"
global.themeemoji = '🪀'
global.wm = "𝐃𝐙𝐀𝐊𝐊𝐘 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋"
global.packname = "𝐃𝐙𝐀𝐊𝐊𝐘 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋"
global.author = "AnanOfficiaL\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://files.catbox.moe/jh7lz3.jpg' }//ur thumb pic
global.defaultpp = 'https://files.catbox.moe/jh7lz3.jpg' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Owner',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
